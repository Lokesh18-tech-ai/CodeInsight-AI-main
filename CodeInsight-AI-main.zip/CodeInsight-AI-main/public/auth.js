// ── Theme ──
const savedTheme = localStorage.getItem("ci_theme") || "dark";
document.documentElement.setAttribute("data-theme", savedTheme);
updateThemeIcon(savedTheme);

document.getElementById("theme-toggle").addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem("ci_theme", next);
  updateThemeIcon(next);
});

function updateThemeIcon(theme) {
  document.getElementById("theme-icon-dark").style.display = theme === "dark" ? "" : "none";
  document.getElementById("theme-icon-light").style.display = theme === "light" ? "" : "none";
}

// ── Redirect if already logged in ──
const existingToken = localStorage.getItem("ci_token");
if (existingToken) {
  fetch("/api/auth/me", { headers: { Authorization: `Bearer ${existingToken}` } })
    .then(r => { if (r.ok) window.location.href = "/"; })
    .catch(() => {});
}

// ── Panel switching ──
function showPanel(id) {
  document.querySelectorAll(".auth-card").forEach(c => c.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
}

document.getElementById("show-signup").addEventListener("click", () => showPanel("panel-signup"));
document.getElementById("show-login").addEventListener("click", () => showPanel("panel-login"));
document.getElementById("show-forgot").addEventListener("click", () => showPanel("panel-forgot"));
document.getElementById("back-to-login").addEventListener("click", () => showPanel("panel-login"));

// ── Password visibility toggle ──
document.querySelectorAll(".eye-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const input = document.getElementById(btn.dataset.target);
    input.type = input.type === "password" ? "text" : "password";
  });
});

// ── Helpers ──
function setLoading(btn, spinnerEl, loading) {
  btn.disabled = loading;
  btn.querySelector("span").textContent = loading
    ? (btn.id === "login-btn" ? "Signing in..." : btn.id === "signup-btn" ? "Creating..." : "Sending...")
    : (btn.id === "login-btn" ? "Sign In" : btn.id === "signup-btn" ? "Create Account" : "Send Reset Link");
  spinnerEl.classList.toggle("hidden", !loading);
}

function showMsg(elId, msg, isSuccess = false) {
  const el = document.getElementById(elId);
  el.textContent = msg;
  el.className = `auth-error${isSuccess ? " success" : ""}`;
}

function hideMsg(elId) {
  const el = document.getElementById(elId);
  el.className = "auth-error hidden";
}

// ── Login ──
document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  const btn = document.getElementById("login-btn");
  const spinner = btn.querySelector(".btn-spinner");

  hideMsg("login-error");
  setLoading(btn, spinner, true);

  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      showMsg("login-error", data.error || "Login failed");
      return;
    }
    localStorage.setItem("ci_token", data.token);
    localStorage.setItem("ci_user", JSON.stringify(data.user));
    localStorage.setItem("ci_theme", data.user.theme || "dark");
    window.location.href = "/";
  } catch {
    showMsg("login-error", "Connection error. Please try again.");
  } finally {
    setLoading(btn, spinner, false);
  }
});

// ── Signup ──
document.getElementById("signup-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("signup-username").value.trim();
  const email = document.getElementById("signup-email").value.trim();
  const password = document.getElementById("signup-password").value;
  const confirm = document.getElementById("signup-confirm").value;
  const btn = document.getElementById("signup-btn");
  const spinner = btn.querySelector(".btn-spinner");

  hideMsg("signup-error");
  if (password !== confirm) { showMsg("signup-error", "Passwords do not match"); return; }
  setLoading(btn, spinner, true);

  try {
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      showMsg("signup-error", data.error || "Registration failed");
      return;
    }
    localStorage.setItem("ci_token", data.token);
    localStorage.setItem("ci_user", JSON.stringify(data.user));
    localStorage.setItem("ci_theme", data.user.theme || "dark");
    window.location.href = "/";
  } catch {
    showMsg("signup-error", "Connection error. Please try again.");
  } finally {
    setLoading(btn, spinner, false);
  }
});

// ── Forgot Password ──
document.getElementById("forgot-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("forgot-email").value.trim();
  const btn = document.getElementById("forgot-btn");
  const spinner = btn.querySelector(".btn-spinner");

  hideMsg("forgot-msg");
  setLoading(btn, spinner, true);

  try {
    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    if (!res.ok) {
      showMsg("forgot-msg", data.error || "Request failed");
      return;
    }
    if (data.devMode && data.resetUrl) {
      showMsg("forgot-msg",
        `Dev mode: Email not configured. Reset link: ${data.resetUrl}`, true);
    } else {
      showMsg("forgot-msg", data.message || "Reset link sent!", true);
    }
  } catch {
    showMsg("forgot-msg", "Connection error. Please try again.");
  } finally {
    setLoading(btn, spinner, false);
  }
});
