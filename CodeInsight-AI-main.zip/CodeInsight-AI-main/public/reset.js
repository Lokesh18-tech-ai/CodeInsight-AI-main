// ── Theme ──
const savedTheme = localStorage.getItem("ci_theme") || "dark";
document.documentElement.setAttribute("data-theme", savedTheme);
updateThemeIcon(savedTheme);

document.getElementById("theme-toggle").addEventListener("click", () => {
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  document.documentElement.setAttribute("data-theme", next);
  localStorage.setItem("ci_theme", next);
  updateThemeIcon(next);
});

function updateThemeIcon(theme) {
  document.getElementById("theme-icon-dark").style.display = theme === "dark" ? "" : "none";
  document.getElementById("theme-icon-light").style.display = theme === "light" ? "" : "none";
}

// ── Password visibility ──
document.querySelectorAll(".eye-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const input = document.getElementById(btn.dataset.target);
    input.type = input.type === "password" ? "text" : "password";
  });
});

// ── Get token from URL ──
const params = new URLSearchParams(window.location.search);
const token = params.get("token");

if (!token) {
  document.getElementById("reset-msg").textContent = "Invalid reset link. Please request a new one.";
  document.getElementById("reset-msg").className = "auth-error";
  document.getElementById("reset-form").style.display = "none";
}

// ── Reset form ──
document.getElementById("reset-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const newPw = document.getElementById("new-password").value;
  const confirmPw = document.getElementById("confirm-password").value;
  const btn = document.getElementById("reset-btn");
  const spinner = btn.querySelector(".btn-spinner");
  const msgEl = document.getElementById("reset-msg");

  msgEl.className = "auth-error hidden";

  if (newPw !== confirmPw) {
    msgEl.textContent = "Passwords do not match";
    msgEl.className = "auth-error";
    return;
  }

  btn.disabled = true;
  btn.querySelector("span").textContent = "Resetting...";
  spinner.classList.remove("hidden");

  try {
    const res = await fetch("/api/auth/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, password: newPw }),
    });
    const data = await res.json();
    if (!res.ok) {
      msgEl.textContent = data.error || "Reset failed";
      msgEl.className = "auth-error";
      btn.disabled = false;
      btn.querySelector("span").textContent = "Reset Password";
      spinner.classList.add("hidden");
      return;
    }
    document.getElementById("reset-panel").classList.add("hidden");
    document.getElementById("success-panel").classList.remove("hidden");
  } catch {
    msgEl.textContent = "Connection error. Please try again.";
    msgEl.className = "auth-error";
    btn.disabled = false;
    btn.querySelector("span").textContent = "Reset Password";
    spinner.classList.add("hidden");
  }
});
