// ── Auth & API helpers ──
function getToken() { return localStorage.getItem("ci_token"); }
function authHeaders() {
  return { "Content-Type": "application/json", "Authorization": `Bearer ${getToken()}` };
}
async function apiFetch(url, opts = {}) {
  return fetch(url, { ...opts, headers: { ...authHeaders(), ...(opts.headers || {}) } });
}

// ── Theme ──
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme || "dark");
  const isDark = (theme || "dark") === "dark";
  document.getElementById("theme-icon-dark").style.display = isDark ? "" : "none";
  document.getElementById("theme-icon-light").style.display = isDark ? "none" : "";
  localStorage.setItem("ci_theme", theme || "dark");
}

async function toggleTheme() {
  const current = document.documentElement.getAttribute("data-theme");
  const next = current === "dark" ? "light" : "dark";
  applyTheme(next);
  try {
    await apiFetch("/api/auth/theme", { method: "PUT", body: JSON.stringify({ theme: next }) });
  } catch (_) {}
}

// ── Auth check on load ──
async function checkAuth() {
  const token = getToken();
  if (!token) { window.location.href = "/auth.html"; return false; }
  try {
    const res = await apiFetch("/api/auth/me");
    if (!res.ok) { logout(); return false; }
    const user = await res.json();
    state.user = user;
    document.getElementById("user-name").textContent = user.username;
    document.getElementById("user-email").textContent = user.email;
    document.getElementById("user-avatar").textContent = user.username[0].toUpperCase();
    applyTheme(localStorage.getItem("ci_theme") || user.theme || "dark");
    return true;
  } catch {
    logout(); return false;
  }
}

function logout() {
  localStorage.removeItem("ci_token");
  localStorage.removeItem("ci_user");
  window.location.href = "/auth.html";
}

// ── Markdown + Highlight setup ──
marked.setOptions({ breaks: true, gfm: true });

// ── State ──
const state = {
  currentPage: "dashboard",
  chatMessages: [],
  isStreaming: false,
  abortController: null,
  user: null,
  historyCache: [],
};

// ── Language Detection ──
const LANG_PATTERNS = [
  { lang: "HTML",       re: /<!DOCTYPE\s+html|<html[\s>]|<body[\s>]|<head[\s>]/i },
  { lang: "SQL",        re: /SELECT\s+.+\s+FROM\s+|INSERT\s+INTO\s+|UPDATE\s+\w+\s+SET\s+|CREATE\s+TABLE\s+/i },
  { lang: "TypeScript", re: /interface\s+\w+\s*\{|type\s+\w+\s*=\s*\{|:\s*(string|number|boolean|any)\[\]?\s*[=;,)]|<\w+>\s*\(/m },
  { lang: "Java",       re: /public\s+(class|static|void)\s+\w+|System\.out\.(print|println)\s*\(|import\s+java\.|void\s+main\s*\(/m },
  { lang: "C++",        re: /std::|cout\s*<<|cin\s*>>|#include\s*<(iostream|vector|string|algorithm|map|set|fstream)\b/m },
  { lang: "C",          re: /#include\s*<(stdio|stdlib|string|math|time|ctype|unistd|errno)\.h>|printf\s*\(|scanf\s*\(|malloc\s*\(|free\s*\(/m },
  { lang: "Rust",       re: /fn\s+main\s*\(\s*\)|let\s+mut\s+\w+|println!\s*\(|use\s+std::|impl\s+\w+/m },
  { lang: "Go",         re: /func\s+\w+\s*\(|fmt\.(Println|Printf|Sprintf)\s*\(|package\s+main\b|:=\s*\w+/m },
  { lang: "Swift",      re: /import\s+UIKit|import\s+SwiftUI|var\s+\w+\s*:\s*\w+\s*=|func\s+\w+\s*\(|guard\s+let\s+/m },
  { lang: "Kotlin",     re: /fun\s+main\s*\(|val\s+\w+\s*:|println\s*\(|data\s+class\s+\w+/m },
  { lang: "PHP",        re: /<\?php\b|echo\s+["']|\$\w+\s*=|function\s+\w+\s*\(.*\)\s*\{/m },
  { lang: "Python",     re: /^\s*def\s+\w+\s*\([^)]*\)\s*:|^\s*from\s+\w+\s+import\s+|^\s*elif\s+.+:|print\s*\(.+\)|^\s*lambda\s+\w+/m },
  { lang: "Ruby",       re: /puts\s+['"\w]|\.each\s*(do|\{)|^\s*end\s*$|require\s+['"][^'"]+['"]/m },
  { lang: "CSS",        re: /^\s*[\w.-]+\s*\{[\s\S]*?:\s*.+;\s*\}|@media\s+|@keyframes\s+|^\s*\.[a-z][\w-]*\s*\{/m },
  { lang: "JavaScript", re: /function\s+\w+\s*\(|const\s+\w+\s*=|let\s+\w+\s*=|var\s+\w+\s*=|=>\s*[\{(]|console\.(log|error|warn)\s*\(|require\s*\(|module\.exports/m },
];

function detectLanguage(text) {
  for (const { lang, re } of LANG_PATTERNS) if (re.test(text)) return lang;
  return null;
}

// ── Navigation ──
function navigate(page) {
  if (state.isStreaming) stopStream();
  state.currentPage = page;
  document.querySelectorAll(".nav-item").forEach(el =>
    el.classList.toggle("active", el.dataset.page === page)
  );
  document.querySelectorAll(".page").forEach(el =>
    el.classList.toggle("active", el.id === `page-${page}`)
  );
  if (page === "dashboard") updateDashboard();
  if (page === "history")   renderHistory("all");
}

// ── Stats (DB-backed) ──
async function fetchStats() {
  try {
    const res = await apiFetch("/api/stats");
    if (!res.ok) return null;
    return await res.json();
  } catch { return null; }
}

async function incrementStat(type) {
  try { await apiFetch(`/api/stats/${type}`, { method: "POST" }); } catch (_) {}
}

// ── History (DB-backed) ──
async function fetchHistory() {
  try {
    const res = await apiFetch("/api/history");
    if (!res.ok) return [];
    const rows = await res.json();
    state.historyCache = rows;
    return rows;
  } catch { return []; }
}

async function saveToHistory(item) {
  try {
    await apiFetch("/api/history", {
      method: "POST",
      body: JSON.stringify({ type: item.type, input: item.input, output: item.output, language: item.language }),
    });
    await incrementStat(item.type);
    updateDashboard();
  } catch (_) {}
}

// ── Dashboard ──
async function updateDashboard() {
  const [stats, history] = await Promise.all([fetchStats(), fetchHistory()]);

  if (stats) {
    document.getElementById("stat-errors").textContent   = stats.errors_explained || 0;
    document.getElementById("stat-analyses").textContent = stats.code_analyses || 0;
    document.getElementById("stat-reviews").textContent  = stats.code_reviews || 0;
    document.getElementById("stat-chats").textContent    = stats.ai_chats || 0;
  }

  const container = document.getElementById("recent-activity");
  const recent = history.slice(0, 6);

  if (!recent.length) {
    container.innerHTML = `<div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      <p>No activity yet. Start by explaining an error or analyzing code.</p>
    </div>`;
    return;
  }

  container.innerHTML = recent.map(item => `
    <div class="recent-item" onclick="openHistoryItem(${item.id})">
      <div class="recent-type-dot" style="background:${typeColor(item.type)}"></div>
      <div class="recent-content">
        <div class="recent-preview">${escapeHtml((item.input_text || "").slice(0, 80))}</div>
        <div class="recent-meta">
          <span class="recent-badge badge-${item.type}">${typeName(item.type)}</span>
          <span class="recent-time">${timeAgo(new Date(item.created_at).getTime())}</span>
        </div>
      </div>
    </div>
  `).join("");
}

function typeColor(type) {
  return {
    error: "#f87171", analyze: "#60a5fa", review: "#34d399", chat: "#fbbf24",
    translate: "#a78bfa", interview: "#38bdf8",
    jobanalyze: "#4ade80", simplify: "#e879f9", sysdesign: "#facc15", roadmap: "#f472b6",
  }[type] || "#94a3b8";
}

function typeName(type) {
  return {
    error: "Error", analyze: "Analysis", review: "Review", chat: "Chat",
    translate: "Translate", interview: "Interview",
    jobanalyze: "JD Analyze", simplify: "Simplify", sysdesign: "Sys Design", roadmap: "Roadmap",
  }[type] || type;
}

function timeAgo(ts) {
  const diff = Date.now() - ts;
  const s = Math.floor(diff / 1000);
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

// ── Streaming Engine ──
async function streamRequest(url, body, outputEl, statusEl, copyBtn, onDone) {
  if (state.isStreaming) stopStream();
  state.isStreaming = true;
  state.abortController = new AbortController();

  let fullText = "";
  statusEl.textContent = "Generating...";
  statusEl.classList.remove("hidden");
  outputEl.innerHTML = `<pre class="streaming-pre"><span id="stream-text"></span><span class="cursor"></span></pre>`;
  const streamTextEl = document.getElementById("stream-text");
  copyBtn.classList.add("hidden");

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: authHeaders(),
      body: JSON.stringify(body),
      signal: state.abortController.signal,
    });

    if (!response.ok) {
      if (response.status === 401) { logout(); return; }
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || "Request failed");
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let nl;
      while ((nl = buffer.indexOf("\n")) !== -1) {
        const line = buffer.slice(0, nl).trim();
        buffer = buffer.slice(nl + 1);
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6);
        if (data === "[DONE]") break;
        try {
          const json = JSON.parse(data);
          const content = json.choices?.[0]?.delta?.content;
          if (content) {
            fullText += content;
            if (streamTextEl) streamTextEl.textContent = fullText;
            outputEl.scrollTop = outputEl.scrollHeight;
          }
        } catch (_) {}
      }
    }
  } catch (err) {
    if (err.name !== "AbortError") {
      outputEl.innerHTML = `<div class="output-placeholder"><p style="color:#f87171">⚠ ${escapeHtml(err.message)}</p></div>`;
      statusEl.classList.add("hidden");
      state.isStreaming = false;
      return;
    }
  }

  if (fullText.trim()) {
    outputEl.innerHTML = `<div class="markdown-body">${marked.parse(fullText)}</div>`;
    outputEl.querySelectorAll("pre code").forEach(el => hljs.highlightElement(el));
    copyBtn.classList.remove("hidden");
  }

  statusEl.classList.add("hidden");
  state.isStreaming = false;
  if (onDone) onDone(fullText);
}

function stopStream() {
  if (state.abortController) { state.abortController.abort(); state.abortController = null; }
  state.isStreaming = false;
}

// ── Tool: Error Explainer ──
function setupExplainer() {
  const input  = document.getElementById("explain-input");
  const output = document.getElementById("explain-output");
  const submit = document.getElementById("explain-submit");
  const clear  = document.getElementById("explain-clear");
  const copy   = document.getElementById("explain-copy");
  const status = document.getElementById("explain-status");
  const badge  = document.getElementById("explain-lang-badge");
  const count  = document.getElementById("explain-char-count");

  input.addEventListener("input", () => {
    count.textContent = `${input.value.length} chars`;
    const lang = detectLanguage(input.value);
    badge.textContent = lang || "";
    badge.classList.toggle("hidden", !lang);
  });

  input.addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") submit.click(); });

  submit.addEventListener("click", () => {
    const val = input.value.trim();
    if (!val) { showToast("Please enter an error or code.", "error"); return; }
    submit.disabled = true;
    streamRequest("/api/explain", { error: val }, output, status, copy, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "error", input: val, output: text });
    });
  });

  clear.addEventListener("click", () => {
    input.value = "";
    count.textContent = "0 chars";
    badge.classList.add("hidden");
    output.innerHTML = `<div class="output-placeholder">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      <p>Your explanation will stream in real-time here</p>
      <span>Press <kbd>Ctrl+Enter</kbd> to submit</span>
    </div>`;
    copy.classList.add("hidden");
    status.classList.add("hidden");
    submit.disabled = false;
  });

  copy.addEventListener("click", () => {
    const md = output.querySelector(".markdown-body");
    navigator.clipboard.writeText(md ? md.innerText : "").then(() => showToast("Copied!", "success"));
  });
}

// ── Tool: Code Analyzer ──
function setupAnalyzer() {
  const input   = document.getElementById("analyze-input");
  const output  = document.getElementById("analyze-output");
  const submit  = document.getElementById("analyze-submit");
  const clear   = document.getElementById("analyze-clear");
  const copy    = document.getElementById("analyze-copy");
  const status  = document.getElementById("analyze-status");
  const badge   = document.getElementById("analyze-lang-badge");
  const langSel = document.getElementById("analyze-lang-select");

  input.addEventListener("input", () => {
    if (langSel.value) return;
    const lang = detectLanguage(input.value);
    badge.textContent = lang || "";
    badge.classList.toggle("hidden", !lang);
  });

  langSel.addEventListener("change", () => {
    badge.textContent = langSel.value || "";
    badge.classList.toggle("hidden", !langSel.value);
  });

  input.addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") submit.click(); });

  submit.addEventListener("click", () => {
    const val = input.value.trim();
    if (!val) { showToast("Please enter code to analyze.", "error"); return; }
    const lang = langSel.value || detectLanguage(val) || "";
    submit.disabled = true;
    streamRequest("/api/analyze", { code: val, language: lang }, output, status, copy, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "analyze", input: val, output: text, language: lang });
    });
  });

  clear.addEventListener("click", () => {
    input.value = "";
    badge.classList.add("hidden");
    langSel.value = "";
    output.innerHTML = `<div class="output-placeholder">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
      <p>Analysis results will stream in real-time here</p>
      <span>Press <kbd>Ctrl+Enter</kbd> to submit</span>
    </div>`;
    copy.classList.add("hidden");
    status.classList.add("hidden");
    submit.disabled = false;
  });

  copy.addEventListener("click", () => {
    const md = output.querySelector(".markdown-body");
    navigator.clipboard.writeText(md ? md.innerText : "").then(() => showToast("Copied!", "success"));
  });
}

// ── Tool: Code Review ──
function setupReview() {
  const input   = document.getElementById("review-input");
  const context = document.getElementById("review-context");
  const output  = document.getElementById("review-output");
  const submit  = document.getElementById("review-submit");
  const clear   = document.getElementById("review-clear");
  const copy    = document.getElementById("review-copy");
  const status  = document.getElementById("review-status");
  const badge   = document.getElementById("review-lang-badge");

  input.addEventListener("input", () => {
    const lang = detectLanguage(input.value);
    badge.textContent = lang || "";
    badge.classList.toggle("hidden", !lang);
  });

  input.addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") submit.click(); });

  submit.addEventListener("click", () => {
    const val = input.value.trim();
    if (!val) { showToast("Please enter code to review.", "error"); return; }
    const lang = detectLanguage(val) || "";
    submit.disabled = true;
    streamRequest("/api/review", { code: val, language: lang, context: context.value.trim() }, output, status, copy, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "review", input: val, output: text, language: lang });
    });
  });

  clear.addEventListener("click", () => {
    input.value = "";
    context.value = "";
    badge.classList.add("hidden");
    output.innerHTML = `<div class="output-placeholder">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      <p>Code review feedback will stream here</p>
      <span>Press <kbd>Ctrl+Enter</kbd> to submit</span>
    </div>`;
    copy.classList.add("hidden");
    status.classList.add("hidden");
    submit.disabled = false;
  });

  copy.addEventListener("click", () => {
    const md = output.querySelector(".markdown-body");
    navigator.clipboard.writeText(md ? md.innerText : "").then(() => showToast("Copied!", "success"));
  });
}

// ── Tool: AI Chat ──
function setupChat() {
  const messagesEl = document.getElementById("chat-messages");
  const inputEl    = document.getElementById("chat-input");
  const sendBtn    = document.getElementById("chat-send");
  const clearBtn   = document.getElementById("chat-clear-btn");
  const welcome    = document.getElementById("chat-welcome");

  inputEl.addEventListener("input", () => {
    inputEl.style.height = "auto";
    inputEl.style.height = Math.min(inputEl.scrollHeight, 120) + "px";
  });

  inputEl.addEventListener("keydown", e => {
    if (e.ctrlKey && e.key === "Enter") { e.preventDefault(); sendMessage(); }
  });

  sendBtn.addEventListener("click", sendMessage);
  clearBtn.addEventListener("click", clearChat);

  document.querySelectorAll(".suggestion-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      inputEl.value = chip.textContent;
      inputEl.dispatchEvent(new Event("input"));
      sendMessage();
    });
  });

  function clearChat() {
    state.chatMessages = [];
    if (state.isStreaming) stopStream();
    messagesEl.innerHTML = "";
    messagesEl.appendChild(welcome);
    welcome.style.display = "";
    inputEl.value = "";
    inputEl.style.height = "auto";
    sendBtn.disabled = false;
  }

  function sendMessage() {
    const text = inputEl.value.trim();
    if (!text || state.isStreaming) return;

    if (welcome) welcome.style.display = "none";

    state.chatMessages.push({ role: "user", content: text });
    appendMessage("user", text);
    inputEl.value = "";
    inputEl.style.height = "auto";
    sendBtn.disabled = true;

    const typingId = "typing-" + Date.now();
    messagesEl.insertAdjacentHTML("beforeend", `
      <div class="message ai typing-indicator" id="${typingId}">
        <div class="message-avatar">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
        </div>
        <div class="message-content">
          <div class="message-bubble">
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
          </div>
        </div>
      </div>
    `);
    messagesEl.scrollTop = messagesEl.scrollHeight;

    let aiText = "";
    state.isStreaming = true;
    state.abortController = new AbortController();

    fetch("/api/chat", {
      method: "POST",
      headers: authHeaders(),
      body: JSON.stringify({ messages: state.chatMessages }),
      signal: state.abortController.signal,
    }).then(async (response) => {
      const typingEl = document.getElementById(typingId);
      if (typingEl) typingEl.remove();

      if (response.status === 401) { logout(); return; }
      if (!response.ok) throw new Error("Request failed");

      const msgId = "msg-" + Date.now();
      messagesEl.insertAdjacentHTML("beforeend", `
        <div class="message ai" id="${msgId}">
          <div class="message-avatar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
          </div>
          <div class="message-content">
            <div class="message-bubble"><pre class="streaming-pre"><span id="${msgId}-text"></span><span class="cursor"></span></pre></div>
            <div class="message-time">${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
          </div>
        </div>
      `);

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let nl;
        while ((nl = buffer.indexOf("\n")) !== -1) {
          const line = buffer.slice(0, nl).trim();
          buffer = buffer.slice(nl + 1);
          if (!line.startsWith("data: ")) continue;
          const data = line.slice(6);
          if (data === "[DONE]") break;
          try {
            const json = JSON.parse(data);
            const content = json.choices?.[0]?.delta?.content;
            if (content) {
              aiText += content;
              const el = document.getElementById(`${msgId}-text`);
              if (el) el.textContent = aiText;
              messagesEl.scrollTop = messagesEl.scrollHeight;
            }
          } catch (_) {}
        }
      }

      const bubble = document.querySelector(`#${msgId} .message-bubble`);
      if (bubble && aiText.trim()) {
        bubble.innerHTML = `<div class="markdown-body">${marked.parse(aiText)}</div>`;
        bubble.querySelectorAll("pre code").forEach(el => hljs.highlightElement(el));
      }
    }).catch(err => {
      const typingEl = document.getElementById(typingId);
      if (typingEl) typingEl.remove();
      if (err.name !== "AbortError") appendMessage("ai", `⚠ ${err.message}`, true);
    }).finally(() => {
      state.isStreaming = false;
      sendBtn.disabled = false;
      if (aiText) {
        state.chatMessages.push({ role: "assistant", content: aiText });
        saveToHistory({ type: "chat", input: text, output: aiText });
      }
    });
  }

  function appendMessage(role, text, isError = false) {
    const isUser = role === "user";
    const initials = state.user ? state.user.username[0].toUpperCase() : "U";
    messagesEl.insertAdjacentHTML("beforeend", `
      <div class="message ${isUser ? "user" : "ai"}">
        <div class="message-avatar">${isUser ? initials :
          `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`
        }</div>
        <div class="message-content">
          <div class="message-bubble">${
            isUser || isError
              ? escapeHtml(text)
              : `<div class="markdown-body">${marked.parse(text)}</div>`
          }</div>
          <div class="message-time">${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
        </div>
      </div>
    `);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
}

// ── History Page ──
let currentFilter = "all";

async function renderHistory(filter) {
  currentFilter = filter;
  const container = document.getElementById("history-list");

  document.querySelectorAll(".filter-btn").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.filter === filter)
  );

  container.innerHTML = `<div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><p>Loading...</p></div>`;

  const history = await fetchHistory();
  const filtered = filter === "all" ? history : history.filter(h => h.type === filter);

  if (!filtered.length) {
    container.innerHTML = `<div class="empty-state">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      <p>No ${filter === "all" ? "" : filter + " "}history yet.</p>
    </div>`;
    return;
  }

  container.innerHTML = filtered.map(item => `
    <div class="history-item" onclick="openHistoryItem(${item.id})">
      <div class="history-item-header">
        <span class="recent-badge badge-${item.type}">${typeName(item.type)}</span>
        ${item.language ? `<span class="lang-badge">${escapeHtml(item.language)}</span>` : ""}
        <span class="history-item-time">${new Date(item.created_at).toLocaleString()}</span>
      </div>
      <div class="history-item-preview">${escapeHtml((item.input_text || "").slice(0, 120))}</div>
    </div>
  `).join("");
}

async function openHistoryItem(id) {
  const history = state.historyCache;
  const item = history.find(h => h.id === id);
  if (!item) return;

  const modal = document.getElementById("modal");
  const title = document.getElementById("modal-title");
  const body  = document.getElementById("modal-body");

  title.textContent = `${typeName(item.type)} — ${new Date(item.created_at).toLocaleString()}`;
  body.innerHTML = `
    <div style="margin-bottom:14px">
      <div style="font-size:12px;font-weight:600;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px">Input</div>
      <pre style="background:var(--hover);border:1px solid var(--card-border);border-radius:6px;padding:12px;font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--text);overflow-x:auto;white-space:pre-wrap">${escapeHtml(item.input_text || "")}</pre>
    </div>
    <div>
      <div style="font-size:12px;font-weight:600;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.5px">AI Response</div>
      <div class="markdown-body">${marked.parse(item.output_text || "")}</div>
    </div>
  `;
  body.querySelectorAll("pre code").forEach(el => hljs.highlightElement(el));
  modal.classList.remove("hidden");
}

// ── Toast ──
let toastTimeout;
function showToast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className = `toast ${type}`;
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => el.classList.add("hidden"), 2500);
}

// ── Utilities ──
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ── Tool: Job Description Analyzer ──
function setupJobAnalyzer() {
  const input      = document.getElementById("jobanalyze-input");
  const background = document.getElementById("jobanalyze-background");
  const output     = document.getElementById("jobanalyze-output");
  const status     = document.getElementById("jobanalyze-status");
  const copyBtn    = document.getElementById("jobanalyze-copy");
  const submit     = document.getElementById("jobanalyze-submit");
  const clearBtn   = document.getElementById("jobanalyze-clear");

  clearBtn.addEventListener("click", () => {
    input.value = ""; background.value = "";
    output.innerHTML = `<div class="output-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg><p>Your skill gap analysis &amp; 30-day prep plan will appear here</p><span>Paste a job description and hit Analyze JD</span></div>`;
    copyBtn.classList.add("hidden");
  });

  async function doAnalyze() {
    const jd = input.value.trim();
    if (!jd) { showToast("Paste a job description first."); return; }
    const bg = background.value.trim();
    submit.disabled = true;
    await streamRequest("/api/jobanalyze", { jd, background: bg }, output, status, copyBtn, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "jobanalyze", input: jd.slice(0, 300), output: text });
    });
  }

  submit.addEventListener("click", doAnalyze);
  input.addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") doAnalyze(); });
  copyBtn.addEventListener("click", () => {
    const md = output.querySelector(".markdown-body");
    navigator.clipboard.writeText(md ? md.innerText : "").then(() => showToast("Copied!"));
  });
}

// ── Tool: Code Simplifier ──
function setupSimplifier() {
  const input    = document.getElementById("simplify-input");
  const output   = document.getElementById("simplify-output");
  const status   = document.getElementById("simplify-status");
  const copyBtn  = document.getElementById("simplify-copy");
  const submit   = document.getElementById("simplify-submit");
  const clearBtn = document.getElementById("simplify-clear");
  const langSel  = document.getElementById("simplify-lang-select");
  const audSel   = document.getElementById("simplify-audience");
  const langBadge = document.getElementById("simplify-lang-badge");

  input.addEventListener("input", () => {
    const detected = detectLanguage(input.value);
    if (detected) { langBadge.textContent = detected; langBadge.classList.remove("hidden"); }
    else langBadge.classList.add("hidden");
  });

  clearBtn.addEventListener("click", () => {
    input.value = ""; langBadge.classList.add("hidden");
    output.innerHTML = `<div class="output-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg><p>Simplified code with step-by-step explanation will appear here</p><span>Concepts, patterns, and gotchas explained in plain English</span></div>`;
    copyBtn.classList.add("hidden");
  });

  async function doSimplify() {
    const code = input.value.trim();
    if (!code) { showToast("Paste some code to simplify."); return; }
    const language = langSel.value || detectLanguage(code) || "";
    const audience = audSel.value;
    submit.disabled = true;
    await streamRequest("/api/simplify", { code, language, audience }, output, status, copyBtn, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "simplify", input: code, output: text, language });
    });
  }

  submit.addEventListener("click", doSimplify);
  input.addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") doSimplify(); });
  copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(output.innerText).then(() => showToast("Copied!"));
  });
}

// ── Tool: System Design Practice ──
function setupSysDesign() {
  const topicInput  = document.getElementById("sysdesign-topic");
  const levelSel    = document.getElementById("sysdesign-level");
  const submit      = document.getElementById("sysdesign-submit");
  const output      = document.getElementById("sysdesign-output");
  const outputCard  = document.getElementById("sysdesign-output-card");
  const outputTitle = document.getElementById("sysdesign-output-title");
  const status      = document.getElementById("sysdesign-status");
  const copyBtn     = document.getElementById("sysdesign-copy");

  async function doDesign() {
    const topic = topicInput.value.trim();
    if (!topic) { showToast("Enter a system to design first."); topicInput.focus(); return; }
    const level = levelSel.value;
    outputTitle.textContent = topic;
    submit.disabled = true;
    outputCard.scrollIntoView({ behavior: "smooth", block: "start" });
    await streamRequest("/api/sysdesign", { topic, level }, output, status, copyBtn, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "sysdesign", input: topic, output: text, language: level });
    });
  }

  submit.addEventListener("click", doDesign);
  topicInput.addEventListener("keydown", e => { if (e.key === "Enter") doDesign(); });
  copyBtn.addEventListener("click", () => {
    const md = output.querySelector(".markdown-body");
    navigator.clipboard.writeText(md ? md.innerText : "").then(() => showToast("Copied!"));
  });
}

// ── Tool: Learning Roadmap ──
function setupLearningRoadmap() {
  const topicInput = document.getElementById("roadmap-topic");
  const levelSel   = document.getElementById("roadmap-level");
  const submit     = document.getElementById("roadmap-submit");
  const output     = document.getElementById("roadmap-output");
  const outputCard = document.getElementById("roadmap-output-card");
  const outputTitle = document.getElementById("roadmap-output-title");
  const status     = document.getElementById("roadmap-status");
  const copyBtn    = document.getElementById("roadmap-copy");

  async function doRoadmap() {
    const topic = topicInput.value.trim();
    if (!topic) { showToast("Enter a topic to learn first."); topicInput.focus(); return; }
    const currentLevel = levelSel.value;
    outputTitle.textContent = `${topic} Roadmap`;
    outputCard.style.display = "";
    submit.disabled = true;
    outputCard.scrollIntoView({ behavior: "smooth", block: "start" });
    await streamRequest("/api/roadmap", { topic, currentLevel }, output, status, copyBtn, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "roadmap", input: topic, output: text, language: currentLevel });
    });
  }

  submit.addEventListener("click", doRoadmap);
  topicInput.addEventListener("keydown", e => { if (e.key === "Enter") doRoadmap(); });
  copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(output.innerText).then(() => showToast("Copied!"));
  });
}

// ── Tool: Code Translator ──
function setupTranslator() {
  const input  = document.getElementById("translate-input");
  const output = document.getElementById("translate-output");
  const status = document.getElementById("translate-status");
  const copyBtn = document.getElementById("translate-copy");
  const submit = document.getElementById("translate-submit");
  const clearBtn = document.getElementById("translate-clear");
  const fromSel = document.getElementById("translate-from");
  const toSel   = document.getElementById("translate-to");
  const charCount = document.getElementById("translate-char-count");
  const langBadge = document.getElementById("translate-lang-badge");

  input.addEventListener("input", () => {
    charCount.textContent = `${input.value.length} chars`;
    const detected = detectLanguage(input.value);
    if (detected) { langBadge.textContent = detected; langBadge.classList.remove("hidden"); }
    else langBadge.classList.add("hidden");
  });

  clearBtn.addEventListener("click", () => {
    input.value = ""; charCount.textContent = "0 chars"; langBadge.classList.add("hidden");
    output.innerHTML = `<div class="output-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 8l6 6"/><path d="M4 14l6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="M22 22l-5-10-5 10"/><path d="M14 18h6"/></svg><p>Translated code with idiomatic explanation will appear here</p><span>Select target language and press Translate</span></div>`;
    copyBtn.classList.add("hidden");
  });

  async function doTranslate() {
    const code = input.value.trim();
    if (!code) { showToast("Paste some code to translate."); return; }
    const to = toSel.value;
    if (!to) { showToast("Select a target language first."); return; }
    const from = fromSel.value || detectLanguage(code) || "";
    submit.disabled = true;
    await streamRequest("/api/translate", { code, from, to }, output, status, copyBtn, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "translate", input: code, output: text, language: `${from || "auto"} → ${to}` });
    });
  }

  submit.addEventListener("click", doTranslate);
  input.addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") doTranslate(); });
  copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(output.innerText).then(() => showToast("Copied!"));
  });
}

// ── Tool: Interview Coach ──
function setupInterviewCoach() {
  const input    = document.getElementById("interview-input");
  const output   = document.getElementById("interview-output");
  const status   = document.getElementById("interview-status");
  const copyBtn  = document.getElementById("interview-copy");
  const submit   = document.getElementById("interview-submit");
  const clearBtn = document.getElementById("interview-clear");
  const levelSel = document.getElementById("interview-level");
  const langSel  = document.getElementById("interview-lang-select");
  const langBadge = document.getElementById("interview-lang-badge");

  input.addEventListener("input", () => {
    const detected = detectLanguage(input.value);
    if (detected) { langBadge.textContent = detected; langBadge.classList.remove("hidden"); }
    else langBadge.classList.add("hidden");
  });

  clearBtn.addEventListener("click", () => {
    input.value = ""; langBadge.classList.add("hidden");
    output.innerHTML = `<div class="output-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg><p>Interview questions and model answers will appear here</p><span>Questions are tailored specifically to your code</span></div>`;
    copyBtn.classList.add("hidden");
  });

  async function doInterview() {
    const code = input.value.trim();
    if (!code) { showToast("Paste some code first."); return; }
    const language = langSel.value || detectLanguage(code) || "";
    const level = levelSel.value;
    submit.disabled = true;
    await streamRequest("/api/interview", { code, language, level }, output, status, copyBtn, (text) => {
      submit.disabled = false;
      if (text) saveToHistory({ type: "interview", input: code, output: text, language });
    });
  }

  submit.addEventListener("click", doInterview);
  input.addEventListener("keydown", e => { if (e.ctrlKey && e.key === "Enter") doInterview(); });
  copyBtn.addEventListener("click", () => {
    navigator.clipboard.writeText(output.innerText).then(() => showToast("Copied!"));
  });
}

// ── Init ──
document.addEventListener("DOMContentLoaded", async () => {
  // Apply saved theme immediately
  const savedTheme = localStorage.getItem("ci_theme") || "dark";
  document.documentElement.setAttribute("data-theme", savedTheme);

  // Auth check
  const authed = await checkAuth();
  if (!authed) return;

  // Navigation
  document.querySelectorAll("[data-page]").forEach(el => {
    el.addEventListener("click", () => navigate(el.dataset.page));
  });

  // Theme toggle
  document.getElementById("theme-toggle").addEventListener("click", toggleTheme);

  // Logout
  document.getElementById("logout-btn").addEventListener("click", () => {
    if (confirm("Sign out of CodeInsight AI?")) logout();
  });

  // Modal close
  document.getElementById("modal-close").addEventListener("click", () =>
    document.getElementById("modal").classList.add("hidden")
  );
  document.getElementById("modal-backdrop").addEventListener("click", () =>
    document.getElementById("modal").classList.add("hidden")
  );

  // History filters
  document.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => renderHistory(btn.dataset.filter));
  });

  // Clear history
  document.getElementById("clear-history-btn").addEventListener("click", async () => {
    if (confirm("Clear all history? This cannot be undone.")) {
      await apiFetch("/api/history", { method: "DELETE" });
      state.historyCache = [];
      renderHistory(currentFilter);
      updateDashboard();
      showToast("History cleared.");
    }
  });

  // Setup tools
  setupExplainer();
  setupAnalyzer();
  setupReview();
  setupChat();
  setupTranslator();
  setupInterviewCoach();
  setupJobAnalyzer();
  setupSimplifier();
  setupSysDesign();
  setupLearningRoadmap();

  // Init dashboard
  updateDashboard();
});
